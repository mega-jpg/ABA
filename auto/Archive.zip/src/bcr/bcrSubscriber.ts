import { Redis } from "ioredis";
import { config } from "../config";
import { handleBcrPubSubMessage } from "./bcrEventHandler";

const CHANNEL = process.env.REDIS_BCR_CHANNEL ?? "bcr:events";

let subscriber: Redis | null = null;

export function getBcrChannel(): string {
  return CHANNEL;
}

export async function startBcrSubscriber(): Promise<Redis> {
  if (subscriber) return subscriber;

  subscriber = new Redis({
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.password,
  });

  await subscriber.subscribe(CHANNEL);

  subscriber.on("message", async (channel, message) => {
    if (channel !== CHANNEL) return;
    console.log(`[BCR Pub/Sub] Nhận event trên ${channel}:`, message.slice(0, 120));
    try {
      const result = await handleBcrPubSubMessage(message);
      if (!result.ok) {
        console.warn(`[BCR Pub/Sub] ${result.message}`);
      } else {
        console.log(`[BCR Pub/Sub] ✅ ${result.message}`);
      }
    } catch (err) {
      console.error("[BCR Pub/Sub] Lỗi xử lý:", (err as Error).message);
    }
  });

  subscriber.on("error", (err) => {
    console.error("[BCR Pub/Sub] Redis error:", err.message);
  });

  console.log(`📡 BCR Pub/Sub đang subscribe channel: ${CHANNEL}`);
  return subscriber;
}

export async function closeBcrSubscriber(): Promise<void> {
  if (subscriber) {
    await subscriber.unsubscribe(CHANNEL);
    await subscriber.quit();
    subscriber = null;
  }
}

/** Publish test event (dùng cho debug) */
export async function publishBcrTestEvent(
  event: string,
  groupId?: string
): Promise<void> {
  const redis = new Redis({
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.password,
  });
  await redis.publish(
    CHANNEL,
    JSON.stringify({ event, groupId, roundId: `test-${Date.now()}` })
  );
  await redis.quit();
}
