import { BcrEventType } from "../types/customScenario";
import { GROUP_HALL_QUESTIONS } from "./bcrQaMessages";
import { humanizeMessages, maybeApplyTypos } from "./bcrTextHumanize";

const WIN_MESSAGES: string[] = [
  "ván này theo anh kéo từ đầu luôn, khen anh share kèo chuẩn nha",
  "anh kéo nhóm timing đúng quá, tin anh không sai luôn á",
  "mình theo kèo anh share mấy ván rồi thấy ổn, khen anh nha",
  "nghe anh kéo nhóm là yên tâm, ván này ăn gọn thật",
  "anh share kèo đúng lúc ghê, theo anh xanh lè luôn",
  "kéo nhóm kiểu này mới thích, anh pro thật sự",
  "cảm ơn anh đã chỉ kèo nha, mình theo đúng timing là ăn",
  "anh kéo mượt quá, ván này chuẩn không bàn cãi luôn",
  "tin anh kéo nhóm từ đầu, không hối hận chút nào",
  "anh timing tốt vl, kèo anh cho hợp bài thật",
  "theo anh kéo mấy phiên rồi thấy uy tín, khen anh",
  "anh kéo đúng hướng r, nghe lời anh là may thật",
  "ván này anh share hay ghê, theo anh là đúng bài",
  "kéo nhóm pro nha anh, mình tin anh từ đầu luôn",
  "anh kèo chuẩn nha, timing vừa đủ không sớm không muộn",
  "nghe anh kéo là pro, ván này ăn sạch luôn á",
  "anh kéo nhóm tốt lắm, cảm ơn anh share kèo nha",
  "theo anh kèo ngon quá, anh phong độ đỉnh thật",
  "kèo anh cho ngon quá, mình theo là xanh lè",
  "anh share kèo xịn, kéo nhóm đúng kèo luôn",
  "tin anh share đúng, ván này không phải bàn cãi",
  "anh kéo nhóm uy tín thật, theo lâu thấy ổn",
  "nghe anh kèo hay, mình theo anh không sai",
  "anh kéo chuẩn ghê, ván này timing anh đỉnh",
  "kéo nhóm share hay, anh ơi ván này chuẩn",
  "theo anh ăn r, khen anh timing tốt nha",
  "anh share đúng lúc ghê, tin anh kèo chuẩn",
  "nghe anh là đúng bài luôn, khen anh kéo pro",
  "anh kéo đúng timing, theo anh kéo tốt lắm",
  "kéo nhóm như anh là thích, anh kéo xịn nha",
  "anh ơi kèo này ngon, theo anh share ngon thật",
  "tin anh từ đầu luôn, anh kéo đúng kèo r",
  "anh kéo nhóm pro ghê, ván này mượt vl",
  "theo anh là hợp bài, anh share kèo tốt",
  "khen anh kéo đúng, nghe anh kéo nhóm là yên",
  "anh timing chuẩn, kéo nhóm ok lắm anh ơi",
  "theo anh kèo hay, anh kéo kèo đúng luôn",
  "nghe anh share là lời, cảm ơn anh kéo nhóm nha",
  "anh kéo nhóm đỉnh thật, tin anh không sai",
  "kéo nhóm chuẩn bài, anh share timing tốt",
  "theo anh ăn gọn, anh kéo uy tín lắm",
  "anh ơi share hay, khen anh kéo hay nha",
  "tin anh kéo đúng, theo anh kèo đúng luôn",
  "anh kéo kèo hay, ván này theo anh là xanh",
  "nghe anh kéo đúng, khen anh share đúng nha",
  "theo anh share đúng, anh kéo nhóm ngon",
  "anh share kèo ngon, kéo nhóm timing tốt",
  "khen anh timing, anh kéo pro ghê thật",
  "theo anh xanh lè, anh kéo đúng bài r",
  "anh kéo nhóm pro, tin anh share kèo nha",
];

const DRAW_MESSAGES: string[] = [
  "ván này hòa thôi anh, ván sau còn kèo gì share tiếp nhé",
  "tie rồi anh ơi, anh kéo tiếp phiên sau được không",
  "hòa keo mà cũng được, anh có tip ván tie này không",
  "anh ơi ván tie này ok không, chờ anh share kèo mới",
  "giữ vốn tie thôi anh, ván sau theo anh kéo tiếp nhé",
  "tie à anh, phiên sau còn kèo không cho mình hỏi",
  "hòa z trời, anh còn phiên kéo không vậy",
  "ván tie anh xem sao, hòa mà chấp nhận được",
  "anh kéo tie xong còn kèo không, chờ anh tip",
  "tie r anh, kèo mới khi nào share tiếp vậy",
  "hòa thôi nhỉ anh, miễn không mất là được",
  "anh ơi tie mà cũng ổn, ván sau kèo gì anh",
  "ván hòa anh kéo tiếp được không, chờ anh nhé",
  "tie keo anh ơi ok không, giữ máu được r",
  "hòa r anh ơi, anh share kèo tiếp giúp em",
  "anh có nhận xét ván tie không, hòa z mà hơi tiếc",
  "tie mà anh có tip gì không, chờ kèo mới",
  "anh ơi giữ vốn tie nha, ván sau theo anh",
  "hòa keo anh kéo tiếp nhé, chờ phiên sau",
  "tie rồi thôi anh, anh kéo tiếp đi nha",
  "ván tie anh tip gì không, hòa mà anh",
  "anh ơi hòa keo luôn hả, ván sau còn không",
  "giữ máu tie ok anh, tie cũng được mà",
  "hòa z anh ơi, kéo tiếp nhé chờ anh share",
  "tie à anh kéo tiếp hả, anh còn phiên không",
  "anh kéo tie rồi tip gì, ván tie này tính sao",
  "hòa thôi anh ơi, ván sau còn kèo hả anh",
  "tie mà anh share kèo tiếp nhé, chờ anh kéo",
  "anh ơi ván tie chấp nhận được, giữ máu thôi",
  "hòa keo anh có kèo gợi ý không, hỏi anh chút",
  "tie r anh share tiếp nhé, ván sau theo ai",
  "anh ơi tie rồi ae, ván sau kèo gì vậy",
  "ván tie anh kéo tiếp được không, ok không anh",
  "hòa r anh kéo tiếp nhé, tie keo anh ơi",
  "giữ vốn tie anh ơi, hòa mà ok lắm",
  "tie mà anh kéo tiếp được không, chờ kèo mới",
  "anh có tip tie không, ván hòa anh xem lại giúp",
  "hòa z tr anh còn phiên không, tie ok anh",
  "anh ơi hòa rồi share kèo tiếp nhé, chờ anh",
  "tie keo anh ơi ok không, giữ máu tie rồi",
  "ván tie anh có kèo mới không, hòa thôi anh",
  "anh ơi tie mà chán ghê, ván sau theo kèo nào",
  "hòa keo anh tip gì không, anh kéo tie luôn hả",
  "tie cũng được anh, có nhận xét gì không",
  "anh kéo tie xong tip gì không, chờ phiên sau",
  "hòa z anh ván sau còn không, tie r anh ơi",
  "anh ơi giữ máu được r, ván tie tạm ổn",
  "tie mà anh ván sau theo ai, kèo tiếp đi anh",
  "hòa thôi anh share kèo tiếp, tie à anh",
  "ván hòa anh ơi ok không, anh có kèo sau tie không",
];

const LOSE_MESSAGES: string[] = [
  "mình vào hơi trễ nên hụt kèo rồi, anh tip ván sau giúp em với",
  "thua tạm thôi anh, ván này timing mình lệch chút",
  "anh ơi ván này xui quá, anh còn kèo gỡ không",
  "thắc mắc ván này anh ơi, anh xem lại giúp được không",
  "mình theo hơi muộn anh ơi, anh tip ván khác nhé",
  "hụt timing r anh, ván sau còn phiên kéo không",
  "thua keo anh ơi, anh share kèo gỡ được không",
  "anh nhận xét ván này đi, mình hơi lỡ tay",
  "gỡ sau ok không anh, chờ anh kéo tiếp nhé",
  "anh xem giúp ván hụt, thắc mắc kèo này anh",
  "mình vào không đúng lúc anh ơi, tip ván sau đi",
  "anh ơi đen bàn này, anh còn kèo mới không",
  "thắc mắc sao ván này hụt anh, xem lại timing giúp",
  "thua r anh, ván sau còn kèo hả, chờ anh share",
  "anh kéo nhóm còn phiên không, mình lỡ kèo rồi",
  "hỏi anh ván sau theo kèo nào, gỡ liền được không",
  "anh tip gì ván sau không, thua tạm thôi anh",
  "mình timing hơi lệch anh ơi, anh xem lại giúp nha",
  "anh ơi hụt keo r, anh kéo tiếp được hả",
  "thắc mắc anh xem giúp, ván này sai hướng hả anh",
  "gỡ được hả anh, anh share tiếp đi nha",
  "anh có kèo gỡ không anh, chờ anh tip",
  "thua tạm anh share kèo đi, ván này hơi xui",
  "anh xem lại ván này với, hỏi anh nhận xét gì",
  "mình theo chậm anh ơi, anh tip đi anh ơi",
  "anh kéo tiếp nhé, thua keo anh kéo tiếp hả",
  "hỏi anh ván này ok không, thắc mắc timing anh",
  "gỡ liền ok không anh, anh còn kèo tiếp không",
  "anh ơi hụt ván này, anh nhận xét giúp ván này",
  "thắc mắc kèo anh ơi, anh xem giúp timing",
  "mình lỡ tay anh ơi, anh có phiên gỡ không",
  "anh kéo nhóm tiếp hả, gỡ sau nhé anh",
  "hỏi anh ván sau sao, thua tạm anh kéo tiếp đi",
  "anh tip ván sau nhé, mình vào muộn anh ơi",
  "thắc mắc ván hụt anh, anh xem giúp ván này sai chỗ nào",
  "gỡ ok không anh ơi, anh có kèo gỡ hả",
  "anh ơi ván này đen quá, tip gì ván này anh",
  "thua r anh còn kèo không, chờ anh share kèo gỡ",
  "anh còn phiên kéo không, hỏi anh xem lại ván này",
  "mình hơi lỡ timing anh ơi, anh tip ván khác đi",
  "anh xem lại giúp, thắc mắc sao hụt anh",
  "gỡ liền hả anh, anh kéo tiếp được không",
  "thua tạm anh ơi anh kéo tiếp nhé, chờ kèo mới",
  "anh share kèo gỡ không, hỏi anh ván sau còn không",
  "anh ơi hụt rồi còn kèo gỡ không, tip gì đi",
  "thắc mắc anh ơi, anh còn phiên không vậy",
  "anh tip gì đi, ván này mình theo muộn quá",
  "hỏi anh sao ván này hụt, anh nhận xét giúp nha",
  "gỡ được không anh ơi, anh còn kèo mới không",
  "anh kéo tiếp nhé anh ơi, thua keo chờ gỡ",
];

const FOLLOW_UP: Record<"win" | "draw" | "lose", string[]> = {
  win: [
    "khen anh kéo hay nha, theo anh tiếp luôn",
    "tin anh kéo nhóm, anh share tiếp nhé",
    "anh kéo chuẩn thật, cảm ơn anh nha",
    "theo anh là đúng, chờ kèo sau anh",
    "ván này ổn quá, anh timing tốt vl",
    "nghe anh là pro, khen anh share đúng",
  ],
  draw: [
    "anh kéo tiếp nhé, chờ anh share kèo mới",
    "ok anh ván sau theo anh, giữ máu r",
    "tie ok anh tiếp đi, còn phiên hả anh",
    "chờ anh kéo tiếp, ván sau theo kèo anh",
    "hòa mà được r, anh share kèo tiếp nhé",
    "giữ máu tie r anh, chờ phiên sau",
  ],
  lose: [
    "anh có kèo gỡ không, chờ anh tip ván sau",
    "gỡ sau được hả anh, anh kéo tiếp nhé",
    "ok anh ván sau theo anh, tip giúp em",
    "chờ anh share kèo gỡ, thua tạm thôi",
    "anh tip ván sau đi, mình chờ anh kéo",
    "gỡ liền ok không anh, chờ kèo mới",
  ],
};

function pickFromPool(pool: string[], count: number): string[] {
  const result: string[] = [];
  for (let i = 0; i < count; i++) result.push(pool[i % pool.length]);
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return humanizeMessages(result);
}

export function getBcrMessages(type: BcrEventType, count = 100): string[] {
  switch (type) {
    case "win":
      return pickFromPool(WIN_MESSAGES, count);
    case "draw":
      return pickFromPool(DRAW_MESSAGES, count);
    case "lose":
      return pickFromPool([...LOSE_MESSAGES, ...GROUP_HALL_QUESTIONS], count);
    case "qa":
      return [];
  }
}

export function getBcrFollowUp(
  type: "win" | "draw" | "lose",
  index: number
): string {
  const pool = FOLLOW_UP[type];
  return maybeApplyTypos(pool[index % pool.length]);
}

export const BCR_EVENT_LABELS: Record<BcrEventType, string> = {
  win: "Khen",
  draw: "Hòa/Hỏi",
  lose: "Thắc mắc",
  qa: "Hỏi đáp",
};
