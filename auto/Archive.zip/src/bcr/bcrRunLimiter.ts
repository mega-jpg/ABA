import fs from "fs/promises";
import path from "path";
import { BcrEventType } from "../types/customScenario";

type DailyRunState = {
  date: string;
  runs: number;
  skips: number;
  updatedAt: string;
};

const DATA_DIR = path.resolve(process.env.DATA_DIR ?? "./data");
const FILE = path.join(DATA_DIR, "bcr-run-limit.json");

function todayKeyVN(): string {
  return new Date()
    .toLocaleString("sv-SE", { timeZone: "Asia/Ho_Chi_Minh" })
    .slice(0, 10);
}

async function loadState(): Promise<DailyRunState> {
  const today = todayKeyVN();
  try {
    const raw = await fs.readFile(FILE, "utf-8");
    const parsed = JSON.parse(raw) as DailyRunState;  
    if (parsed.date === today) return parsed;
  } catch {
    // ignore
  }
  return {
    date: today,
    runs: 0,
    skips: 0,
    updatedAt: new Date().toISOString(),
  };
}

async function saveState(state: DailyRunState): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(FILE, JSON.stringify(state, null, 2));
}

export async function shouldRunBcrEvent(
  eventType: BcrEventType
): Promise<{ allow: boolean; reason?: string; runsToday: number; maxPerDay: number }> {
  const maxRaw = Number(process.env.BCR_MAX_RUNS_PER_DAY ?? 5);
  const maxPerDay = Number.isFinite(maxRaw) && maxRaw > 0 ? Math.floor(maxRaw) : 5;
  const probRaw = Number(process.env.BCR_RUN_PROBABILITY ?? 0.8);
  const probability =
    Number.isFinite(probRaw) && probRaw >= 0 && probRaw <= 1 ? probRaw : 0.8;

  // QA thường là test/manual, không bóp theo quota.
  if (eventType === "qa") {
    return { allow: true, runsToday: 0, maxPerDay };
  }

  const state = await loadState();
  if (state.runs >= maxPerDay) {
    state.skips += 1;
    state.updatedAt = new Date().toISOString();
    await saveState(state);
    return {
      allow: false,
      reason: `đủ quota ngày (${state.runs}/${maxPerDay})`,
      runsToday: state.runs,
      maxPerDay,
    };
  }

  const passRandom = Math.random() < probability;
  if (!passRandom) {
    state.skips += 1;
    state.updatedAt = new Date().toISOString();
    await saveState(state);
    return {
      allow: false,
      reason: `random skip (p=${probability})`,
      runsToday: state.runs,
      maxPerDay,
    };
  }

  state.runs += 1;
  state.updatedAt = new Date().toISOString();
  await saveState(state);
  return { allow: true, runsToday: state.runs, maxPerDay };
}
