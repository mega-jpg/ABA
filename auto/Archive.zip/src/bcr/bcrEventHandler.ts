import { pickNextBcrScenario } from "./bcrScenarioDeck";
import { parseBcrPubSubMessage } from "./bcrEventParser";
import {
  markScenarioRun,
  getScenario,
} from "../admin/services/scenarioStore";
import { scheduleSeedingScript } from "../queue/scheduler";
import { BcrEventType, CustomScenario } from "../types/customScenario";
import { BCR_EVENT_LABELS, getBcrMessages } from "./bcrMessages";
import { listClones } from "../admin/services/resourceService";
import { SeedingScript, SeedingStep } from "../types/seeding";
import { shouldRunBcrEvent } from "./bcrRunLimiter";

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function buildRuntimeConversationScript(
  scenario: CustomScenario,
  eventType: BcrEventType,
  groupId: string,
  aliveCloneIds: string[]
): SeedingScript {
  const targetMessages = randomInt(5, 10);
  const existingTexts = scenario.steps
    .filter((s) => s.action === "send_message" && !!s.text?.trim())
    .map((s) => String(s.text).trim());
  const generatedTexts = getBcrMessages(eventType, targetMessages + 6);
  const texts = Array.from({ length: targetMessages }, (_, i) =>
    existingTexts[i] ?? generatedTexts[i] ?? generatedTexts[0] ?? "ok anh"
  );

  const aliveSet = new Set(aliveCloneIds);
  const preferred = Array.from(
    new Set(
      scenario.steps
        .map((s) => s.cloneId)
        .filter((id) => aliveSet.has(id))
    )
  );
  const participants: string[] = [...preferred];
  for (const id of aliveCloneIds) {
    if (participants.length >= Math.min(4, aliveCloneIds.length)) break;
    if (!participants.includes(id)) participants.push(id);
  }
  if (participants.length === 0) {
    participants.push(...aliveCloneIds.slice(0, 1));
  }

  const steps: SeedingStep[] = texts.map((text, i) => {
    const cloneId = participants[i % participants.length];
    return {
      cloneId,
      action: "send_message",
      payload: {
        text,
        ...(i > 0 ? { replyToPrevious: true } : {}),
      },
      delayBefore: i === 0 ? randomInt(2, 6) : randomInt(6, 20),
    };
  });

  return {
    id: `wf-${scenario.id.slice(0, 8)}-${Date.now()}`,
    name: scenario.name,
    chatId: groupId,
    steps,
  };
}

export async function handleBcrPubSubMessage(
  raw: string
): Promise<{ ok: boolean; message: string; workflowId?: string }> {
  const parsed = parseBcrPubSubMessage(raw);
  if (!parsed) {
    return { ok: false, message: `Không parse được event: ${raw.slice(0, 100)}` };
  }

  const { eventType, groupId } = parsed;
  const gate = await shouldRunBcrEvent(eventType);
  if (!gate.allow) {
    return {
      ok: true,
      message: `${BCR_EVENT_LABELS[eventType]}: bỏ qua (${gate.reason})`,
    };
  }

  const clones = await listClones();
  const aliveCloneIds = clones.map((c) => c.id);
  if (aliveCloneIds.length === 0) {
    return {
      ok: false,
      message: "Không có clone sống để chạy kịch bản",
    };
  }

  const scenario = await pickNextBcrScenario(eventType);

  if (!scenario) {
    return {
      ok: false,
      message: `Không có kịch bản BCR ${BCR_EVENT_LABELS[eventType]} — chạy npm run seed:bcr`,
    };
  }

  const resolved = groupId
    ? { ...scenario, groupId }
    : scenario;
  const script = buildRuntimeConversationScript(
    resolved,
    eventType,
    resolved.groupId,
    aliveCloneIds
  );

  const workflowId = await scheduleSeedingScript(script);
  await markScenarioRun(scenario.id, workflowId);

  console.log(
    `[BCR] ${BCR_EVENT_LABELS[eventType]} → kịch bản "${scenario.name}" → workflow ${workflowId}`
  );

  return {
    ok: true,
    workflowId,
    message: `${BCR_EVENT_LABELS[eventType]}: chạy "${scenario.name}" (${script.steps.length} tin)`,
  };
}

export async function runBcrScenarioById(
  scenarioId: string,
  groupIdOverride?: string
): Promise<string> {
  const scenario = await getScenario(scenarioId);
  if (!scenario) throw new Error("Kịch bản không tồn tại");

  const resolved = groupIdOverride
    ? { ...scenario, groupId: groupIdOverride }
    : scenario;

  const clones = await listClones();
  const aliveCloneIds = clones.map((c) => c.id);
  if (aliveCloneIds.length === 0) {
    throw new Error("Không có clone sống để chạy kịch bản");
  }
  const eventType = resolved.eventType ?? "qa";
  const script = buildRuntimeConversationScript(
    resolved,
    eventType,
    resolved.groupId,
    aliveCloneIds
  );
  const workflowId = await scheduleSeedingScript(script);
  await markScenarioRun(scenario.id, workflowId);
  return workflowId;
}

export type { BcrEventType };
