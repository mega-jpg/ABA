/**
 * Cho tất cả session sống join group target
 *
 * Usage:
 *   npm run join:group -- --invite "https://t.me/+AbCdEfGh"
 *   npm run join:group -- --invite "https://t.me/+xxx" --group-id -1003709178070
 *   npm run join:group -- --username "ten_group_public"
 */
import fs from "fs/promises";
import path from "path";
import dotenv from "dotenv";
import { getTelegramClient, disconnectClient } from "../telegram/clientPool";
import {
  isInGroup,
  safeJoinByInvite,
  safeJoinByUsername,
} from "../telegram/safeTele";
import { SessionsManifest } from "../types/sessionsManifest";
import { randomDelay } from "../types/seeding";
import { isFloodWait } from "../goResult";

dotenv.config();

const MANIFEST_PATH = path.resolve(
  process.env.SESSIONS_MANIFEST ?? "./clones/sessions.manifest.json"
);

function getArg(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  return idx !== -1 ? process.argv[idx + 1] : undefined;
}

function sleep(sec: number): Promise<void> {
  return new Promise((r) => setTimeout(r, sec * 1000));
}

async function loadInviteFromConfig(): Promise<{
  inviteLink?: string;
  username?: string;
  groupId?: string;
}> {
  try {
    const cfgPath = path.resolve(process.env.SEEDING_CONFIG ?? "./seeding.config.json");
    const cfg = JSON.parse(await fs.readFile(cfgPath, "utf-8")) as {
      groups?: Array<{ id: string; enabled?: boolean; inviteLink?: string; username?: string }>;
      target?: { groupId?: string };
    };
    const group =
      cfg.groups?.find((g) => g.id === cfg.target?.groupId) ??
      cfg.groups?.find((g) => g.enabled) ??
      cfg.groups?.[0];
    return {
      inviteLink: group?.inviteLink,
      username: group?.username,
      groupId: cfg.target?.groupId ?? group?.id,
    };
  } catch {
    return {};
  }
}

async function main(): Promise<void> {
  const fromConfig = await loadInviteFromConfig();
  const inviteLink = getArg("--invite") ?? fromConfig.inviteLink;
  const username = getArg("--username") ?? fromConfig.username;
  const groupIdArg = getArg("--group-id") ?? fromConfig.groupId;

  if (!inviteLink && !username) {
    console.log(`
Cách join group cho các session sống:

  npm run join:group -- --invite "https://t.me/+LINK_MOI_GROUP"

  # Group public (có @username):
  npm run join:group -- --username "ten_group"

  # Kiểm tra đã join chưa (cần group-id):
  npm run join:group -- --invite "https://t.me/+xxx" --group-id -1003709178070

Lấy link mời: vào group → Add members → Invite link → Copy
`);
    process.exit(1);
  }

  const raw = await fs.readFile(MANIFEST_PATH, "utf-8");
  const manifest = JSON.parse(raw) as SessionsManifest;
  const sessions = manifest.sessions.filter((s) => s.enabled);

  const targetGroup = groupIdArg
    ?? manifest.groups.find((g) => g.enabled)?.groupId
    ?? manifest.groups[0]?.groupId;

  console.log(`\n=== Join group cho ${sessions.length} session sống ===`);
  if (targetGroup) console.log(`📌 Group ID: ${targetGroup}`);
  if (inviteLink) console.log(`🔗 Invite  : ${inviteLink}`);
  if (username) console.log(`📛 Username: @${username.replace(/^@/, "")}`);
  console.log("");

  let joined = 0;
  let already = 0;
  let failed = 0;

  for (let i = 0; i < sessions.length; i++) {
    const s = sessions[i];
    const label = s.firstName ?? s.username ?? s.id;

    const [client, connErr] = await getTelegramClient(s.id);
    if (connErr) {
      console.log(`❌ [${i + 1}/${sessions.length}] ${s.id} — lỗi kết nối: ${connErr.message}`);
      failed++;
      continue;
    }

    try {
      if (targetGroup) {
        const member = await isInGroup(client, targetGroup);
        if (member) {
          console.log(`⏭️  [${i + 1}/${sessions.length}] ${label} — đã trong group rồi`);
          already++;
          await disconnectClient(s.id);
          continue;
        }
      }

      let joinErr: Error | null = null;

      if (inviteLink) {
        const [, err] = await safeJoinByInvite(client, inviteLink);
        joinErr = err;
      } else if (username) {
        const [, err] = await safeJoinByUsername(client, username);
        joinErr = err;
      }

      if (joinErr) {
        if (isFloodWait(joinErr)) {
          const wait = parseInt(joinErr.message.match(/(\d+)/)?.[1] ?? "60", 10);
          console.log(`⏳ FLOOD_WAIT ${wait}s — chờ rồi thử lại ${label}...`);
          await sleep(wait + 5);
          i--;
          continue;
        }
        if (joinErr.message.includes("USER_ALREADY_PARTICIPANT")) {
          console.log(`⏭️  [${i + 1}/${sessions.length}] ${label} — đã trong group`);
          already++;
        } else {
          console.log(`❌ [${i + 1}/${sessions.length}] ${label} — ${joinErr.message}`);
          failed++;
        }
      } else {
        console.log(`✅ [${i + 1}/${sessions.length}] ${label} — join thành công`);
        joined++;
      }
    } finally {
      await disconnectClient(s.id);
    }

    if (i < sessions.length - 1) {
      const delay = randomDelay(10, 30);
      console.log(`   ⏸  Chờ ${delay}s...`);
      await sleep(delay);
    }
  }

  console.log(`\n=== Kết quả ===`);
  console.log(`✅ Join mới  : ${joined}`);
  console.log(`⏭️  Đã có sẵn : ${already}`);
  console.log(`❌ Lỗi       : ${failed}`);
  console.log(`\n   Tiếp theo: npm run run:once\n`);
}

main().catch((err) => {
  console.error("Lỗi:", err.message);
  process.exit(1);
});
